// Import the contents of your other files
importScripts('default_filters.js', 'block.js');

// Your service worker initialization code can go here
console.log('Service worker initialized'); 